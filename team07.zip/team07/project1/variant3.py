# This is necessary to find the main code
import sys
sys.path.insert(0, '../../bomberman')
sys.path.insert(1, '..')

# Import necessary stuff
import random
from game import Game
from monsters.selfpreserving_monster import SelfPreservingMonster

# TODO This is your code!
sys.path.insert(1, '../teamNN')
from testcharacter import TestCharacter
from interactivecharacter import InteractiveCharacter

# Create the game
# random.seed(123) # TODO Change this if you want different random choices
for x in range(10):
    g = Game.fromfile('map.txt')
    g.add_monster(SelfPreservingMonster("selfpreserving", # name
                                        "S",              # avatar
                                        3, 9,             # position
                                        1                 # detection range
    ))

    # TODO Add your character
    # g.add_character(TestCharacter("me", # name
    #                             "C",  # avatar
    #                             0, 0  # position
    # ))

    g.add_character(InteractiveCharacter("me", # name
                                         "C",  # avatar
                                         0, 0  # position
    ))

    # Run!
    g.go(0)
